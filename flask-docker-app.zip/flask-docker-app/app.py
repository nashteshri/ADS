from flask import Flask
import os

app = Flask(__name__)

@app.route('/')
def home():
    # Read environment variables
    app_env = os.getenv('APP_ENV', 'Development')
    return f" Shrinivas Nashte,PRN-2122000635,ROLL NO-(B40)"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)
